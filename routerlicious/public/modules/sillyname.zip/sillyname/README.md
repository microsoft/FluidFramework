### Silly name

A random name generator.

````
var generateName = require('sillyname');
var sillyName = generateName();
````

**Some example results:**

* Saltfollower Pickle
* Roadtoe Ginger
* Tidegargoyle Warp
* Geodecollar Daffodil
* Timeelk Fluff
* Slimetooth Black
* Coffeeparrot Giant
* Clevermoth Power
* Pinkserpent Quasar
* Greatgorilla Sunset